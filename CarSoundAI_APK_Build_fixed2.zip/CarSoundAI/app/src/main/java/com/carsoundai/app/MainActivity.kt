package com.carsoundai.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.*
import android.media.audiofx.Equalizer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    private var eq: Equalizer? = null
    private var sessionId = 0
    private var micResult by mutableStateOf("아직 측정하지 않았어요.")

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) measureMic()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(
            play = { playSample(it) },
            stop = { stopAudio() },
            setEq = { band, db -> setBand(band, db) },
            preset = { applyPreset(it) },
            measure = { requestMic() },
            micText = { micResult }
        ) }
    }

    private fun playSample(sample: Int) {
        stopAudio()
        val id = when (sample) { 0 -> R.raw.bass_test; 1 -> R.raw.vocal_test; else -> R.raw.balance_test }
        player = MediaPlayer.create(this, id)?.apply {
            sessionId = audioSessionId
            start()
            setOnCompletionListener { it.seekTo(0) }
        }
        try {
            if (sessionId != 0) eq = Equalizer(0, sessionId).apply { enabled = true }
        } catch (_: Exception) { eq = null }
    }

    private fun setBand(band: Int, db: Int) {
        try {
            val effect = eq ?: return
            if (band !in 0 until effect.numberOfBands.toInt()) return
            val range = effect.bandLevelRange
            effect.setBandLevel(band.toShort(), (db * 100).coerceIn(range[0].toInt(), range[1].toInt()).toShort())
        } catch (_: Exception) {}
    }

    private fun applyPreset(preset: Int) {
        val levels = when (preset) {
            0 -> listOf(4, 3, 0, 1, 2)
            1 -> listOf(-1, 0, 3, 4, 2)
            else -> listOf(0, 1, 1, 1, 0)
        }
        levels.forEachIndexed { i, value -> setBand(i, value) }
    }

    private fun stopAudio() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
        try { eq?.release() } catch (_: Exception) {}
        eq = null; sessionId = 0
    }

    private fun requestMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) measureMic()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun measureMic() {
        Thread {
            val rate = 44100
            val size = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (size <= 0) { runOnUiThread { micResult = "이 기기에서는 마이크 측정을 시작할 수 없어요." }; return@Thread }
            var rec: AudioRecord? = null
            try {
                rec = AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, size)
                val buf = ShortArray(size / 2)
                var squares = 0.0; var count = 0
                rec.startRecording()
                val end = System.currentTimeMillis() + 3000
                while (System.currentTimeMillis() < end) {
                    val n = rec.read(buf, 0, buf.size)
                    for (i in 0 until n.coerceAtLeast(0)) {
                        val v = buf[i] / 32768.0
                        squares += v * v; count++
                    }
                }
                val rms = if (count > 0) sqrt(squares / count) else 0.0
                runOnUiThread { micResult = "마이크 상대 레벨: %.4f (보정되지 않은 참고값)".format(rms) }
            } catch (_: Exception) {
                runOnUiThread { micResult = "측정에 실패했어요. 마이크 권한을 확인해 주세요." }
            } finally {
                try { rec?.stop() } catch (_: Exception) {}
                rec?.release()
            }
        }.start()
    }

    override fun onDestroy() { stopAudio(); super.onDestroy() }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App(
        play: (Int) -> Unit, stop: () -> Unit, setEq: (Int, Int) -> Unit,
        preset: (Int) -> Unit, measure: () -> Unit, micText: () -> String
    ) {
        var step by remember { mutableIntStateOf(0) }
        var choice by remember { mutableIntStateOf(-1) }
        var bass by remember { mutableFloatStateOf(0f) }
        var mid by remember { mutableFloatStateOf(0f) }
        var treble by remember { mutableFloatStateOf(0f) }
        val titles = listOf("취향 찾기", "저음 다듬기", "보컬 선명도", "전체 균형", "최종 확인")
        val guides = listOf(
            "테스트 소리를 듣고 가장 마음에 드는 소리를 골라 주세요.",
            "저음이 단단하고 풍부하게 들리도록 조절해요.",
            "가수의 목소리가 악기 사이에서 또렷하게 들리도록 조절해요.",
            "저음부터 고음까지 어느 한쪽도 튀지 않게 맞춰요.",
            "평소 듣는 음악으로 확인하고 마음에 드는 설정을 찾아요."
        )
        MaterialTheme {
            Scaffold(topBar = { TopAppBar(title = { Text("카사운드 AI") }) }) { pad ->
                Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LinearProgressIndicator(progress = { (step + 1) / 5f }, modifier = Modifier.fillMaxWidth())
                    Text("STEP ${step + 1} / 5 · ${titles[step]}", style = MaterialTheme.typography.titleLarge)
                    Text(guides[step])
                    if (step == 0) {
                        Button(onClick = { play(0) }, modifier = Modifier.fillMaxWidth()) { Text("저음 테스트 듣기") }
                        Button(onClick = { play(1) }, modifier = Modifier.fillMaxWidth()) { Text("보컬 테스트 듣기") }
                        Button(onClick = { play(2) }, modifier = Modifier.fillMaxWidth()) { Text("전체 균형 테스트 듣기") }
                        OutlinedButton(onClick = stop, modifier = Modifier.fillMaxWidth()) { Text("정지") }
                        Text("어떤 느낌이 좋아요?")
                        listOf("저음이 풍부한 소리", "보컬이 선명한 소리", "자연스럽고 균형 잡힌 소리").forEachIndexed { i, label ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = choice == i, onClick = { choice = i; preset(i) })
                                Text(label)
                            }
                        }
                        Text("샘플은 직접 합성한 테스트 신호이며 음악이 아닙니다.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("저음")
                        Slider(value = bass, onValueChange = { bass = it; setEq(0, it.toInt()) }, valueRange = -6f..6f)
                        Text("${bass.toInt()} dB")
                        Text("중음")
                        Slider(value = mid, onValueChange = { mid = it; setEq(2, it.toInt()) }, valueRange = -6f..6f)
                        Text("${mid.toInt()} dB")
                        Text("고음")
                        Slider(value = treble, onValueChange = { treble = it; setEq(4, it.toInt()) }, valueRange = -6f..6f)
                        Text("${treble.toInt()} dB")
                        OutlinedButton(onClick = measure, modifier = Modifier.fillMaxWidth()) { Text("마이크로 3초 측정") }
                        Text(micText())
                        Text("현재 측정은 상대 음량 참고값뿐이며 주파수별 실내 보정은 아직 구현되지 않았어요.",
                            style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { play(2) }, modifier = Modifier.fillMaxWidth()) { Text("현재 설정으로 테스트 듣기") }
                        OutlinedButton(onClick = stop, modifier = Modifier.fillMaxWidth()) { Text("정지") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { if (step > 0) step-- }, enabled = step > 0, modifier = Modifier.weight(1f)) { Text("이전") }
                        Button(onClick = { if (step < 4) step++ else { step = 0; stop() } }, modifier = Modifier.weight(1f)) {
                            Text(if (step < 4) "다음 단계" else "처음부터")
                        }
                    }
                    Text("차량 블루투스 연결 후 사용하세요. EQ 적용 여부는 스마트폰과 차량에 따라 달라질 수 있어요.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
